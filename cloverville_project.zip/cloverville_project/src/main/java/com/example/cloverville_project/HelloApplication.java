package com.example.cloverville_project;

import javafx.application.Application;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) {
        // Load saved data first
        ClovervilleFacade.loadAll();

        SceneManager.setStage(stage);
        SceneManager.switchTo("hello-view.fxml");
        stage.setTitle("Cloverville");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

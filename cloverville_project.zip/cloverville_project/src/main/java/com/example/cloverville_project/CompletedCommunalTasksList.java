package com.example.cloverville_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CompletedCommunalTasksList {

    private final ObservableList<CommunalTask> list = FXCollections.observableArrayList();

    public ObservableList<CommunalTask> getList() {
        return list;
    }

    public void add(CommunalTask task) {
        list.add(task);
    }
}

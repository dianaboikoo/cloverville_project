package com.example.cloverville_project;

public class Resident {

    private String name;
    private int age;
    private String occupation;

    private OwnedTradeOfferList ownedTradeOffers = new OwnedTradeOfferList();
    private AssignedTradeOfferList assignedTradeOffers = new AssignedTradeOfferList();
    private CompletedGreenActionsList completedGreenActions = new CompletedGreenActionsList();
    private CompletedCommunalTasksList completedCommunalTasks = new CompletedCommunalTasksList();

    public Resident(String name, int age, String occupation) {
        this.name = name;
        this.age = age;
        this.occupation = occupation;
    }

    public Resident() {}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public OwnedTradeOfferList getOwnedTradeOffers() {
        return ownedTradeOffers;
    }

    public AssignedTradeOfferList getAssignedTradeOffers() {
        return assignedTradeOffers;
    }

    public CompletedGreenActionsList getCompletedGreenActions() {
        return completedGreenActions;
    }

    public CompletedCommunalTasksList getCompletedCommunalTasks() {
        return completedCommunalTasks;
    }

    public void setOwnedTradeOffers(OwnedTradeOfferList list) {
        this.ownedTradeOffers = list;
    }

    public void setAssignedTradeOffers(AssignedTradeOfferList list) {
        this.assignedTradeOffers = list;
    }

    public void setCompletedGreenActions(CompletedGreenActionsList list) {
        this.completedGreenActions = list;
    }

    public void setCompletedCommunalTasks(CompletedCommunalTasksList list) {
        this.completedCommunalTasks = list;
    }

    @Override
    public String toString() {
        return name;
    }
}

package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class TaskEditController {

    @FXML private TextField titleField;
    @FXML private TextField descriptionField;
    @FXML private Button saveButton;
    @FXML private Button backButton;

    private CommunalTask activeTask;

    @FXML
    public void initialize() {
        activeTask = TaskLog.getActiveTask();

        if (activeTask != null) {
            titleField.setText(activeTask.getTitle());
            descriptionField.setText(activeTask.getDescription());
        }
    }

    @FXML
    private void onSave() {
        if (activeTask != null) {
            activeTask.setTitle(titleField.getText());
            activeTask.setDescription(descriptionField.getText());
            DataExporter.save();
        }

        SceneManager.switchTo("task-list.fxml");
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("task-list.fxml");
    }
}

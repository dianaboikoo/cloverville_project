package com.example.cloverville_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ResidentList {

    private final ObservableList<Resident> residents = FXCollections.observableArrayList();

    public ObservableList<Resident> getResidents() {
        return residents;
    }

    public void add(Resident resident) {
        residents.add(resident);
    }

    public void remove(Resident resident) {
        residents.remove(resident);
    }
}

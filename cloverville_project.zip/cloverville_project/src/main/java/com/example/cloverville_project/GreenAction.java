package com.example.cloverville_project;

public class GreenAction {

    private String title;
    private int points;

    public GreenAction(String title, int points) {
        this.title = title;
        this.points = points;
    }

    public GreenAction() {}

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
    public String toString() {
        return title + " (" + points + " pts)";
    }
}

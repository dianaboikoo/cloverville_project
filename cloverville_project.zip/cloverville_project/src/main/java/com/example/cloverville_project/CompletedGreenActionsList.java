package com.example.cloverville_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CompletedGreenActionsList {

    private final ObservableList<GreenAction> list = FXCollections.observableArrayList();

    public ObservableList<GreenAction> getList() {
        return list;
    }

    public void add(GreenAction action) {
        list.add(action);
    }
}

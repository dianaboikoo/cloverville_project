package com.example.cloverville_project;

public class DataExporter {

    public static void save() {
        ClovervilleFacade.saveAll();
        System.out.println("✔ Data saved.");
    }

    public static void load() {
        ClovervilleFacade.loadAll();
        System.out.println("✔ Data loaded.");
    }
}

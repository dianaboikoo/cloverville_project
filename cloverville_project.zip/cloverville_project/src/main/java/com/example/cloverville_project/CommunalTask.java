package com.example.cloverville_project;

public class CommunalTask {

    private String title;
    private String description;

    public CommunalTask(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public CommunalTask() {}

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return title;
    }
}

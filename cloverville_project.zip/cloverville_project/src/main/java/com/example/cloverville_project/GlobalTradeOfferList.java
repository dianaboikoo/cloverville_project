package com.example.cloverville_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class GlobalTradeOfferList {

    private final ObservableList<TradeOffer> offers = FXCollections.observableArrayList();

    public ObservableList<TradeOffer> getOffers() {
        return offers;
    }

    public void add(TradeOffer offer) {
        offers.add(offer);
    }

    public void remove(TradeOffer offer) {
        offers.remove(offer);
    }
}

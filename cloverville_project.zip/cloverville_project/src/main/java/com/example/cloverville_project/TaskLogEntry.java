package com.example.cloverville_project;

public class TaskLogEntry {

    private String date;
    private String description;

    public TaskLogEntry(String date, String description) {
        this.date = date;
        this.description = description;
    }

    public TaskLogEntry() {}

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

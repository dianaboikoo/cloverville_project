package com.example.cloverville_project;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;

public class ClovervilleFacade {

    private static ResidentList residentList = new ResidentList();
    private static GlobalTradeOfferList globalTradeOfferList = new GlobalTradeOfferList();
    private static Resident activeResident;

    private static final String SAVE_PATH = "cloverville_data.json";

    public static ResidentList getResidentList() {
        return residentList;
    }

    public static GlobalTradeOfferList getGlobalTradeOfferList() {
        return globalTradeOfferList;
    }

    public static Resident getActiveResident() {
        return activeResident;
    }

    public static void setActiveResident(Resident resident) {
        activeResident = resident;
    }

    // Residents
    public static void addResident(Resident resident) {
        residentList.add(resident);
    }

    public static void removeResident(Resident resident) {
        residentList.remove(resident);
    }

    // Global trade offers
    public static void addGlobalTradeOffer(TradeOffer offer) {
        globalTradeOfferList.add(offer);
    }

    public static void removeGlobalTradeOffer(TradeOffer offer) {
        globalTradeOfferList.remove(offer);
    }

    // Posting and taking offers
    public static void residentPostsTradeOffer(Resident resident, TradeOffer offer) {
        if (resident != null && offer != null) {
            resident.getOwnedTradeOffers().add(offer);
            globalTradeOfferList.add(offer);
        }
    }

    public static void assignTradeOfferToResident(Resident resident, TradeOffer offer) {
        if (resident != null && offer != null) {
            resident.getAssignedTradeOffers().add(offer);
        }
    }

    public static void residentTakesTradeOffer(Resident resident, TradeOffer offer) {
        if (resident == null || offer == null) return;

        resident.getAssignedTradeOffers().remove(offer);
        resident.getOwnedTradeOffers().remove(offer);
        globalTradeOfferList.remove(offer);
    }

    // Green actions
    public static void completeGreenAction(Resident resident, GreenAction action) {
        if (resident != null && action != null) {
            resident.getCompletedGreenActions().add(action);
        }
    }

    // Communal tasks
    public static void completeCommunalTask(Resident resident, CommunalTask task) {
        if (resident != null && task != null) {
            resident.getCompletedCommunalTasks().add(task);
        }
    }

    // Saving & loading all data

    static class DataWrapper {
        Resident[] residents;
        TradeOffer[] globalOffers;
    }

    public static void saveAll() {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            DataWrapper wrapper = new DataWrapper();
            wrapper.residents = residentList.getResidents().toArray(new Resident[0]);
            wrapper.globalOffers = globalTradeOfferList.getOffers().toArray(new TradeOffer[0]);

            FileWriter fw = new FileWriter(SAVE_PATH);
            gson.toJson(wrapper, fw);
            fw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadAll() {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            FileReader fr = new FileReader(SAVE_PATH);
            DataWrapper wrapper = gson.fromJson(fr, DataWrapper.class);
            fr.close();

            residentList = new ResidentList();
            globalTradeOfferList = new GlobalTradeOfferList();

            if (wrapper.residents != null) {
                for (Resident r : wrapper.residents) {
                    residentList.add(r);
                }
            }
            if (wrapper.globalOffers != null) {
                for (TradeOffer o : wrapper.globalOffers) {
                    globalTradeOfferList.add(o);
                }
            }

        } catch (Exception e) {
            // first run: file may not exist -> ignore
        }
    }
}

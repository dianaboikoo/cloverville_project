package com.example.cloverville_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class OwnedTradeOfferList {

    private final ObservableList<TradeOffer> list = FXCollections.observableArrayList();

    public ObservableList<TradeOffer> getList() {
        return list;
    }

    public void add(TradeOffer offer) {
        list.add(offer);
    }

    public void remove(TradeOffer offer) {
        list.remove(offer);
    }
}

package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class EditController {

    @FXML private TextField nameField;
    @FXML private TextField ageField;
    @FXML private TextField occupationField;

    @FXML
    public void initialize() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r != null) {
            nameField.setText(r.getName());
            ageField.setText(String.valueOf(r.getAge()));
            occupationField.setText(r.getOccupation());
        }
    }

    @FXML
    private void onSave() {
        String name = nameField.getText();
        String occ = occupationField.getText();
        int age = Integer.parseInt(ageField.getText());

        Resident active = ClovervilleFacade.getActiveResident();

        if (active == null) {
            active = new Resident(name, age, occ);
            ClovervilleFacade.addResident(active);
        } else {
            active.setName(name);
            active.setAge(age);
            active.setOccupation(occ);
        }

        DataExporter.save();
        SceneManager.switchTo("list-view.fxml");
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("list-view.fxml");
    }
}

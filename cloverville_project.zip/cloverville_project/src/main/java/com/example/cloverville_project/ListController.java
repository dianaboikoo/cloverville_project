package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class ListController {

    @FXML
    private ListView<Resident> residentsListView;

    @FXML
    private Button editButton;

    @FXML
    private Button tasksButton;

    @FXML
    private Button tradeOffersButton;

    @FXML
    private Button greenActionsButton;

    @FXML
    private Button addResidentButton;

    @FXML
    public void initialize() {
        residentsListView.setItems(
                ClovervilleFacade.getResidentList().getResidents()
        );

        editButton.setDisable(true);
        tasksButton.setDisable(true);
        tradeOffersButton.setDisable(true);
        greenActionsButton.setDisable(true);

        residentsListView.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            boolean hasSelection = newVal != null;
            editButton.setDisable(!hasSelection);
            tasksButton.setDisable(!hasSelection);
            tradeOffersButton.setDisable(!hasSelection);
            greenActionsButton.setDisable(!hasSelection);

            if (hasSelection) {
                ClovervilleFacade.setActiveResident(newVal);
            }
        });
    }

    @FXML
    private void onAddResident() {
        ClovervilleFacade.setActiveResident(null);
        SceneManager.switchTo("edit-view.fxml");
    }

    @FXML
    private void onEditResident() {
        SceneManager.switchTo("edit-view.fxml");
    }

    @FXML
    private void onOpenTasks() {
        SceneManager.switchTo("task-list.fxml");
    }

    @FXML
    private void onOpenTradeOffers() {
        SceneManager.switchTo("trade_offers.fxml");
    }

    @FXML
    private void onOpenGreenActions() {
        SceneManager.switchTo("green-action.fxml");
    }
}

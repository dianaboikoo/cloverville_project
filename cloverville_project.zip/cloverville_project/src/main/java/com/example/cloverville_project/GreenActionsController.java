package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class GreenActionsController {

    @FXML private TextField titleField;
    @FXML private TextField pointsField;
    @FXML private Button addButton;
    @FXML private Button backButton;
    @FXML private ListView<GreenAction> actionsListView;

    @FXML
    public void initialize() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r != null) {
            actionsListView.setItems(r.getCompletedGreenActions().getList());
        }
    }

    @FXML
    private void onAddAction() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r == null) return;

        String title = titleField.getText();
        int points = Integer.parseInt(pointsField.getText());

        GreenAction action = new GreenAction(title, points);
        ClovervilleFacade.completeGreenAction(r, action);

        titleField.clear();
        pointsField.clear();
        DataExporter.save();
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("list-view.fxml");
    }
}

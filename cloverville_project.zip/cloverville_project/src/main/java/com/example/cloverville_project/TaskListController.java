package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class TaskListController {

    @FXML private ListView<CommunalTask> completedTasksListView;
    @FXML private Button completeTaskButton;
    @FXML private Button editTaskButton;
    @FXML private Button backButton;

    @FXML
    public void initialize() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r != null) {
            completedTasksListView.setItems(r.getCompletedCommunalTasks().getList());
        }
    }

    @FXML
    private void onCompleteTask() {
        SceneManager.switchTo("complete-task.fxml");
    }

    @FXML
    private void onEditTask() {
        CommunalTask selected = completedTasksListView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            TaskLog.setActiveTask(selected);
            SceneManager.switchTo("task-edit.fxml");
        }
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("list-view.fxml");
    }
}

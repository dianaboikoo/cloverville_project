package com.example.cloverville_project;

public class TaskLog {

    private static CommunalTask activeTask;

    public static void setActiveTask(CommunalTask task) {
        activeTask = task;
    }

    public static CommunalTask getActiveTask() {
        return activeTask;
    }
}

package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class CompleteTaskController {

    @FXML private TextField titleField;
    @FXML private TextField descriptionField;
    @FXML private Button addButton;
    @FXML private Button backButton;
    @FXML private ListView<CommunalTask> completedTasksListView;

    @FXML
    public void initialize() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r != null) {
            completedTasksListView.setItems(r.getCompletedCommunalTasks().getList());
        }
    }

    @FXML
    private void onAddTask() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r == null) return;

        String title = titleField.getText();
        String desc = descriptionField.getText();

        CommunalTask task = new CommunalTask(title, desc);
        ClovervilleFacade.completeCommunalTask(r, task);

        titleField.clear();
        descriptionField.clear();
        DataExporter.save();
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("task-list.fxml");
    }
}

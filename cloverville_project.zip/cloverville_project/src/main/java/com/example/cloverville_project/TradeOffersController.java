package com.example.cloverville_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class TradeOffersController {

    @FXML private ListView<TradeOffer> globalOffersListView;
    @FXML private ListView<TradeOffer> ownedOffersListView;
    @FXML private ListView<TradeOffer> assignedOffersListView;

    @FXML private TextField offerTitleField;
    @FXML private TextField offerDescriptionField;

    @FXML private Button postOfferButton;
    @FXML private Button takeOfferButton;
    @FXML private Button backButton;

    @FXML
    public void initialize() {
        globalOffersListView.setItems(ClovervilleFacade.getGlobalTradeOfferList().getOffers());

        Resident r = ClovervilleFacade.getActiveResident();
        if (r != null) {
            ownedOffersListView.setItems(r.getOwnedTradeOffers().getList());
            assignedOffersListView.setItems(r.getAssignedTradeOffers().getList());
        }
    }

    @FXML
    private void onPostOffer() {
        Resident r = ClovervilleFacade.getActiveResident();
        if (r == null) return;

        String title = offerTitleField.getText();
        String desc = offerDescriptionField.getText();

        TradeOffer offer = new TradeOffer(title, desc, r.getName());
        ClovervilleFacade.residentPostsTradeOffer(r, offer);

        offerTitleField.clear();
        offerDescriptionField.clear();
        DataExporter.save();
    }

    @FXML
    private void onTakeOffer() {
        Resident r = ClovervilleFacade.getActiveResident();
        TradeOffer selected = globalOffersListView.getSelectionModel().getSelectedItem();

        if (r != null && selected != null) {
            ClovervilleFacade.assignTradeOfferToResident(r, selected);
            DataExporter.save();
        }
    }

    @FXML
    private void onBack() {
        SceneManager.switchTo("list-view.fxml");
    }
}
